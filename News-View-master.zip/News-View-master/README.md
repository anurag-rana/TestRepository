# News-View

<h5 align="center">
<img src="https://github.com/chaostools/News-View/blob/master/screen%20shots/ic_launcher-web.png" height="142" width="142" >
</h5>

One Of my First Android's project.A simple usage of REST API call using picasso and okhttp.This is a simple app which will show you some most latest news in the form of "news-shots" on the go.Click on the News to read synopsis of it or go to its full link.
## Networking Libraries used
- `compile 'com.squareup.okhttp3:okhttp:3.9.0'`
-  `compile 'com.squareup.picasso:picasso:2.5.2'`

#### ScreenShots:
<img src="https://github.com/chaostools/News-View/blob/master/screen%20shots/Screenshot_2017-12-28-23-11-15.png" >
<img src="https://github.com/chaostools/News-View/blob/master/screen%20shots/Screenshot_2017-12-28-23-11-42.png" >
<img src= "https://github.com/chaostools/News-View/blob/master/screen%20shots/Screenshot_2017-12-28-23-11-30.png" >
<img src="https://github.com/chaostools/News-View/blob/master/screen%20shots/Screenshot_2017-12-28-23-06-06.png" >






